<?php
include 'db.php';

$sql = "SELECT * FROM rooms WHERE capacity > (SELECT COUNT(*) FROM students WHERE students.room_allotted = rooms.room_no)";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Available Rooms</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h2>Available Rooms</h2>
    <table border="1" cellpadding="8">
        <tr>
            <th>Room No</th>
            <th>Capacity</th>
        </tr>
        <?php
        if ($result && $result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<tr><td>{$row['room_no']}</td><td>{$row['capacity']}</td></tr>";
            }
        } else {
            echo "<tr><td colspan='2'>No available rooms.</td></tr>";
        }
        $conn->close();
        ?>
    </table>
</body>
</html>