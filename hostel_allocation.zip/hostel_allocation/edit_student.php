<?php
include 'db.php';

$id = $_GET['id'];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $reg_no = $_POST['reg_no'];
    $gender = $_POST['gender'];
    $room_pref = $_POST['room_pref'];
    $room_allotted = $_POST['room_allotted'];

    $sql = "UPDATE students SET 
            name='$name', 
            reg_no='$reg_no', 
            gender='$gender', 
            room_pref='$room_pref', 
            room_allotted='$room_allotted' 
            WHERE id=$id";

    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Student updated successfully'); window.location.href='view_students.php';</script>";
    } else {
        echo "Error updating record: " . $conn->error;
    }
} else {
    $sql = "SELECT * FROM students WHERE id=$id";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Student</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>Edit Student</h1>
    <form method="POST">
        <input type="text" name="name" value="<?php echo $row['name']; ?>" required>
        <input type="text" name="reg_no" value="<?php echo $row['reg_no']; ?>" required>

        <select name="gender" required>
            <option value="">Select Gender</option>
            <option value="Male" <?php if($row['gender'] == 'Male') echo 'selected'; ?>>Male</option>
            <option value="Female" <?php if($row['gender'] == 'Female') echo 'selected'; ?>>Female</option>
        </select>

        <select name="room_pref" required>
            <option value="">Room Preference</option>
            <option value="Single" <?php if($row['room_pref'] == 'Single') echo 'selected'; ?>>Single</option>
            <option value="Shared" <?php if($row['room_pref'] == 'Shared') echo 'selected'; ?>>Shared</option>
        </select>

        <select name="room_allotted" required>
            <option value="">Room Allotted</option>
            <option value="101" <?php if($row['room_allotted'] == '101') echo 'selected'; ?>>101</option>
            <option value="102" <?php if($row['room_allotted'] == '102') echo 'selected'; ?>>102</option>
            <option value="103" <?php if($row['room_allotted'] == '103') echo 'selected'; ?>>103</option>
            <option value="201" <?php if($row['room_allotted'] == '201') echo 'selected'; ?>>201</option>
            <option value="202" <?php if($row['room_allotted'] == '202') echo 'selected'; ?>>202</option>
        </select>

        <input type="submit" value="Update Student">
    </form>
</body>
</html>