<?php
include 'db.php';

$sql = "SELECT * FROM students";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Registered Students</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            padding: 20px;
            background: #f2f2f2;
        }
        h1 {
            text-align: center;
        }
        .search-container {
            text-align: center;
            margin-bottom: 15px;
        }
        input[type="text"] {
            padding: 8px;
            width: 250px;
            border-radius: 6px;
            border: 1px solid #ccc;
        }
        .table-container {
            overflow-x: auto;
        }
        table {
            border-collapse: collapse;
            width: 100%;
            background: #fff;
            border-radius: 10px;
            overflow: hidden;
        }
        th, td {
            border: 1px solid #eee;
            padding: 10px;
            text-align: center;
        }
        th {
            background: #007bff;
            color: white;
        }
        a {
            margin: 0 5px;
            text-decoration: none;
            color: #007bff;
        }
        .actions {
            white-space: nowrap;
        }
        .btn-group {
            text-align: center;
            margin: 15px;
        }
        button {
            padding: 8px 12px;
            margin: 0 5px;
            border: none;
            background: #007bff;
            color: white;
            border-radius: 5px;
            cursor: pointer;
        }
        button:hover {
            background: #0056b3;
        }
    </style>
</head>
<body>
    <h1>Registered Students</h1>

    <div class="search-container">
        <input type="text" id="search" placeholder="Search by name or reg no">
    </div>

    <div class="btn-group">
        <button onclick="window.print()">Print</button>
        <button onclick="exportTableToCSV()">Export to Excel</button>
        <button onclick="window.location.href='index.html'">Back to Home</button>
    </div>

    <div class="table-container">
        <table id="studentTable">
            <tr>
                <th>Name</th>
                <th>Registration No</th>
                <th>Gender</th>
                <th>Room Preference</th>
                <th>Room Allotted</th>
                <th>Actions</th>
            </tr>
            <?php while($row = $result->fetch_assoc()) { ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['name']); ?></td>
                    <td><?php echo htmlspecialchars($row['reg_no']); ?></td>
                    <td><?php echo htmlspecialchars($row['gender']); ?></td>
                    <td><?php echo isset($row['room_pref']) ? htmlspecialchars($row['room_pref']) : 'N/A'; ?></td>
                    <td><?php echo htmlspecialchars($row['room_allotted']); ?></td>
                    <td class="actions">
                        <a href="edit_student.php?id=<?php echo $row['id']; ?>">Edit</a>
                        <a href="delete_student.php?id=<?php echo $row['id']; ?>" onclick="return confirm('Are you sure you want to delete this student?');">Delete</a>
                    </td>
                </tr>
            <?php } ?>
        </table>
    </div>

    <script>
        const searchInput = document.getElementById("search");
        searchInput.addEventListener("input", function () {
            const filter = searchInput.value.toLowerCase();
            const rows = document.querySelectorAll("#studentTable tr:not(:first-child)");
            rows.forEach(row => {
                const name = row.children[0].textContent.toLowerCase();
                const regNo = row.children[1].textContent.toLowerCase();
                row.style.display = (name.includes(filter) || regNo.includes(filter)) ? "" : "none";
            });
        });

        function exportTableToCSV() {
            let csv = [];
            const rows = document.querySelectorAll("table tr");
            for (let i = 0; i < rows.length; i++) {
                const row = [], cols = rows[i].querySelectorAll("td, th");
                for (let j = 0; j < cols.length - 1; j++) {
                    row.push('"' + cols[j].innerText + '"');
                }
                csv.push(row.join(","));
            }
            const csvFile = new Blob([csv.join("\n")], { type: "text/csv" });
            const downloadLink = document.createElement("a");
            downloadLink.download = "registered_students.csv";
            downloadLink.href = window.URL.createObjectURL(csvFile);
            downloadLink.click();
        }
    </script>
</body>
</html>