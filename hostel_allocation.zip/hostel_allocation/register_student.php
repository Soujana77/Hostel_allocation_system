<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $reg_no = $_POST['reg_no'];
    $gender = $_POST['gender'];
    $room_pref = $_POST['room_pref'];
    $room_allotted = $_POST['room_allotted'];

    // Check for duplicate registration
    $checkQuery = "SELECT * FROM students WHERE reg_no = '$reg_no'";
    $checkResult = $conn->query($checkQuery);

    if ($checkResult->num_rows > 0) {
        echo "<script>alert('Student with this Registration Number already exists!'); window.location.href = 'index.html';</script>";
    } else {
        $sql = "INSERT INTO students (name, reg_no, gender, room_pref, room_allotted)
                VALUES ('$name', '$reg_no', '$gender', '$room_pref', '$room_allotted')";

        if ($conn->query($sql) === TRUE) {
            echo "<script>alert('Student registered successfully!'); window.location.href = 'index.html';</script>";
        } else {
            echo "Error: " . $conn->error;
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Register Student</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>Register Student</h1>
    <form method="POST" action="">
        <input type="text" name="name" placeholder="Full Name" required>
        <input type="text" name="reg_no" placeholder="Registration Number" required>
        
        <select name="gender" required>
            <option value="">Select Gender</option>
            <option value="Male">Male</option>
            <option value="Female">Female</option>
        </select>

        <input type="text" name="room_pref" placeholder="Preferred Room Number">
        <input type="text" name="room_allotted" placeholder="Allotted Room Number">

        <input type="submit" value="Register">
    </form>
</body>
</html>